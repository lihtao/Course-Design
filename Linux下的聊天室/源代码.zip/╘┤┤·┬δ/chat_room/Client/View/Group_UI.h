
#ifndef _GROUP_UI_H
#define _GROUP_UI_H
void Group_UI_ShowList();

void Group_UI_Create();

void Group_UI_AddMember(int gid);
#endif
